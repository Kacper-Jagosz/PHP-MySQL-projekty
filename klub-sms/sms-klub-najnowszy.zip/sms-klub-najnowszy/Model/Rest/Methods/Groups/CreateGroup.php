<?php

namespace Otcf\ClubSMS\Model\Rest\Methods\Groups;

use Otcf\ClubSMS\Service\Request;

class CreateGroup implements \Otcf\ClubSMS\Api\Rest\RedlinkInterface
{
    private $request;

    public function __construct(
        Request $request
    ) {
        $this->request = $request;
    }

    public function execute ()
    {
        // NIE MA OBSLUGI W SOAPIE, DOPYTAC PRZEMKA
        
        // $name = $_POST['name'];
        // $description = $_POST['description'];
        // $extrnalId = $_POST['externalId'];

        // $payload = 
        //     object([
        //         'name' => $name,
        //         'description' => $description,
        //         'externalId' => $extrnalId
        //     ]);

        // $response = $this->request->createGroup($payload);
    }

}