<?php

namespace Otcf\ClubSMS\Model\Rest\Methods\Contacts;

use Otcf\ClubSMS\Service;
use Otcf\ClubSMS\Api\Rest;

require "../../../../Service/Request.php";
require "../../../../Api/Rest/RedlinkInterface.php";

class DeleteContact implements Rest\RedlinkInterface
{
    private $request;

    public function __construct(
        // Request $request
    ) {
        $this->request = new Service\Request();
    }

    public function execute ()
    {
        $contactsId = $_POST['contactsId'];

        $payload = 
            (object)[
                'id' => $contactsId
            ];

        $response = $this->request->deleteContacts($payload);
        echo ($response);
    }

}

if ($_POST['contactsId']) {
    $deleteContact = new DeleteContact();
    $deleteContact->execute();
}