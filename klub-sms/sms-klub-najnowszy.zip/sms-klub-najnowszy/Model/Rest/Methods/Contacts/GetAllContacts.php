<?php

namespace Otcf\ClubSMS\Model\Rest\Methods\Contacts;

use Otcf\ClubSMS\Service;
use Otcf\ClubSMS\Api\Rest;

require "../../../../Service/Request.php";
require "../../../../Api/Rest/RedlinkInterface.php";

class GetAllContacts implements Rest\RedlinkInterface
{
    private $request;

    public function __construct(
        // Request $request
    )
    {
        $this->request = new Service\Request();
    }

    public function execute()
    {
        $response = $this->request->getAllContacts();
        var_dump($response);
    }
}

$getAllContacts = new GetAllContacts();
$getAllContacts->execute();
