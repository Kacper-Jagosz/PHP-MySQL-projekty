<?php

namespace Otcf\ClubSMS\Model\Rest\Methods\Contacts;

use Otcf\ClubSMS\Service;
use Otcf\ClubSMS\Api\Rest;

require $_SERVER['DOCUMENT_ROOT'] . "/sms-klub/Service/Request.php";
require $_SERVER['DOCUMENT_ROOT'] . "/sms-klub/Api/Rest/RedlinkInterface.php";

class GetContactByPhoneNumber implements Rest\RedlinkInterface
{
    private $request;

    public function __construct(
        // Request $request
    )
    {
        $this->request = new Service\Request();
    }

    public function execute()
    {
        $phoneNumber = '0' . $_POST['mobilePhone'];
        $response = $this->request->getContactByPhoneNumber($phoneNumber);
        echo $response;
    }
}

if ($_POST['mobilePhone']) {
    $getContactByPhoneNumber = new GetContactByPhoneNumber();
    $getContactByPhoneNumber->execute();
}
