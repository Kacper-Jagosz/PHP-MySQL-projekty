<?php

namespace Otcf\ClubSMS\Model\Rest\Methods\Contacts;

use Otcf\ClubSMS\Service;
use Otcf\ClubSMS\Api\Rest;

require $_SERVER['DOCUMENT_ROOT'] . "/sms-klub/Service/Request.php";
require $_SERVER['DOCUMENT_ROOT'] . "/sms-klub/Api/Rest/RedlinkInterface.php";

class AddContactToGroup implements Rest\RedlinkInterface
{
    private $request;

    public function __construct(
        // Request $request
    )
    {
        $this->request = new Service\Request();
    }

    public function execute()
    {
        $contactId = $_POST['contactId'];

        $payload =
            (object) [
                'id' => [
                    (int)$contactId
                ],
            ];

        $response = $this->request->addContactToGroup(json_encode($payload));
        echo ($response);
    }
}

    if ($_POST['contactId']) {
        $addContactToGroup = new AddContactToGroup();
        $addContactToGroup->execute();
    }
