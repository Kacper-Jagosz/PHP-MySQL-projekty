<?php
namespace Otcf\ClubSMS\Model\Rest\Methods\Contacts;

use Otcf\ClubSMS\Service;
use Otcf\ClubSMS\Api\Rest;

require $_SERVER['DOCUMENT_ROOT'] . "/sms-klub/Service/Request.php";
require $_SERVER['DOCUMENT_ROOT'] . "/sms-klub/Api/Rest/RedlinkInterface.php";


class AddContact implements Rest\RedlinkInterface
{
    private $request;

    public function __construct(
        // Request $request
    )
    {
        $this->request = new Service\Request();
    }

    public function execute()
    {
        $phoneNumber = '+48' . $_POST['mobilePhone'];
        $city = $_POST['city'];
        $promotionCode = $this->getPromotionCode();
        
        $payload = [
            (object) [
                'phoneNumber' => $phoneNumber,
                'externalData' => (object) [
                    'Miasto' => $city,
                    'kod_rabatowy' => $promotionCode
                ],
            ],
        ];

        $response = $this->request->addContact(json_encode($payload));
        echo ($response);
    }
    
    private function getPromotionCode(): string
    {
        $url = "https://script.google.com/macros/s/AKfycbw5KG4iD2HY5UrVGrQWLgPyj68jrFAFgiVEKJ5D61zJjm2rWgO5/exec";
        $json = file_get_contents($url);
        $jsonData = json_decode($json, true);
        
        return $jsonData[0];
    }
}

if ($_POST['mobilePhone'] && $_POST['city']) {
    $addContact = new AddContact();
    $addContact->execute();
}