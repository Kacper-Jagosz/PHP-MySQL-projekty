<?php

namespace Otcf\ClubSMS\Api\Singleton;

interface SingletonInterface
{
    public static function getInstance();
}