<?php

namespace Otcf\ClubSMS\Api\Rest;

interface RedlinkInterface
{
    public function execute();
}