<?php

namespace Otcf\ClubSMS\Config;

use Otcf\ClubSMS\Api\Singleton;

require $_SERVER['DOCUMENT_ROOT'] . "/sms-klub/Api/Singleton/SingletonInterface.php";

class Config implements Singleton\SingletonInterface
{
    /**
     * @var Config
     */
    private static $_instance = null;

    private $configuration;

    private function __construct()
    {
        $file = file_get_contents($_SERVER['DOCUMENT_ROOT'] . "/sms-klub/Config/configuration.json") ?? [];
        $this->configuration = json_decode($file, true);
    }

    public static function getInstance(): Config
    {
        if (self::$_instance == null) {
            self::$_instance = new Self;
        }
        return self::$_instance;
    }

    public function __destruct()
    {
        self::$_instance = null;
    }

    public function getConfiguration() 
    {
        return $this->configuration;
    }
}
