<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <!--<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" /> -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700|Roboto+Condensed:700&amp;subset=latin-ext"
        rel="stylesheet">
    <link rel="stylesheet" href="css/style-v8.css" media="screen">
    <title>Outhorn Klub SMS</title>
		<link rel="shortcut icon" href="https://outhorn.com/gfx/i1567171356.ico">
	  <link rel="icon" href="https://outhorn.com/gfx/i1567171356.ico">
</head>

<body>
    <div id="bg"></div>
    <div id="root">

        <a href="https://outhorn.com/">
            <div id="logo"><img src="img/logo-oth-v5.png" alt=""></div>
            <div id="newsletter-logo"><img src="img/header-v5.png" alt=""></div>
        </a>


        <div class="form-wrapper">
            <p class="news-descript">Jako pierwszy dowiesz się o nowościach w ofercie,<br>
                aktualnych promocjach i specjalnych akcjach rabatowych.<br>
                Odbierz zniżkę 40 zł* dla nowych subskrybentów!
            </p>

            <div class="number-wrapper">

                <form method="post" action="" id="number-form">
                    <div class="digits">
                        <span class="number">+48</span>
                        <div class="digit"><input name="digit-1" type="text" maxlength="1" placeholder="_" required="">
                        </div>
                        <div class="digit"><input name="digit-2" type="text" maxlength="1" placeholder="_" required="">
                        </div>
                        <div class="digit"><input name="digit-3" type="text" maxlength="1" placeholder="_" required="">
                        </div>
                        <div class="digit"><input name="digit-4" type="text" maxlength="1" placeholder="_" required="">
                        </div>
                        <div class="digit"><input name="digit-5" type="text" maxlength="1" placeholder="_" required="">
                        </div>
                        <div class="digit"><input name="digit-6" type="text" maxlength="1" placeholder="_" required="">
                        </div>
                        <div class="digit"><input name="digit-7" type="text" maxlength="1" placeholder="_" required="">
                        </div>
                        <div class="digit"><input name="digit-8" type="text" maxlength="1" placeholder="_" required="">
                        </div>
                        <div class="digit"><input name="digit-9" type="text" maxlength="1" placeholder="_" required="">
                        </div>
                    </div>
                    <!-- <div class="checkbox">
                            <input type="checkbox" id="agree1" value="true"  /><label for="agree1"><span></span>Wyrażam zgodę na przetwarzanie moich danych osobowych i wykorzystywanie ich w celach marketingowych (zgodnie z ustawą z dnia 29.08.1997r. o ochronie danych osobowych, tj. Dz.U z 2002 roku, nr 101, poz. 926 z późn. zm.) przez OTCF Sp. z o.o. z siedzibą w Wieliczce (32-020) ul. Grottgera 30, wpisaną do KRS pod nr 0000555276 prowadzonego przez Wydział Gospodarczy Sadu Rejonowego w Krakowie.</label>
                        </div> -->
                    <div class="checkbox">
                        <input type="checkbox" id="agree2" value="true"><label for="agree2"><span></span>Wyrażam zgodę
                            na otrzymywanie korespondencji handlowej w postaci wiadomości SMS zgodnie z <a
                                href="https://outhorn.com/regulamin-e-sklepu,8,51.htm">Regulaminem Sklepu
                                Internetowego</a>. Przysługuje mi prawo cofnięcia zgody na przetwarzania danych w każdym
                            czasie, co nie będzie jednak miało wpływu na zgodność przetwarzania z prawem realizowanego
                            przed cofnięciem zgody.</label>
                    </div>
                    <!-- <div class="checkbox">
                            <input type="checkbox" id="agree3" value="true"  /><label for="agree3"><span></span>Wyrażam zgodę na przetwarzanie mojego numeru telefonu przez OTCF S.A. w celu otrzymywania wiadomości „Newsletter SMS”.</label>
                        </div> -->

                        <div class="bottom-wrapper">
                            <div class="btns-wrapper">
                                <div class="desktop-select-container">
                                        <div class="select-box">
                                        <div class="options-container">
                                            <label class="district" for="">woj. dolnośląskie</label>
                                            <div class="option">
                                            <input
                                                type="radio"
                                                class="radio"
                                                id="Głogów"
                                                name="category"
                                            />
                                            <label for="Głogów">Głogów</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Jawor" name="category" />
                                            <label for="Jawor">Jawor</label>
                                            </div>

                                            <div class="option">
                                            <input type="radio" class="radio" id="Kłodzko" name="category" />
                                            <label for="Kłodzko">Kłodzko</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Lubin" name="category" />
                                            <label for="Lubin">Lubin</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Milicz" name="category" />
                                            <label for="Milicz">Milicz</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Strzelin" name="category" />
                                            <label for="Strzelin">Strzelin</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Świdnica" name="category" />
                                            <label for="Świdnica">Świdnica</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Trzebnica" name="category" />
                                            <label for="Trzebnica">Trzebnica</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Wrocław" name="category" />
                                            <label for="Wrocław">Wrocław</label>
                                            </div>
                                
                                            <label class="district" for="">woj. kujawsko-pomorskie</label>

                                            <div class="option">
                                            <input type="radio" class="radio" id="Bydgoszcz" name="category" />
                                            <label for="Bydgoszcz">Bydgoszcz</label>
                                            </div>

                                            <label class="district" for="">woj. lubelskie</label>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Biała Podlaska" name="category" />
                                            <label for="Biała Podlaska">Biała Podlaska</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Biłgoraj" name="category" />
                                            <label for="Biłgoraj">Biłgoraj</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Janów Lubelski" name="category" />
                                            <label for="Janów Lubelski">Janów Lubelski</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Kraśnik" name="category" />
                                            <label for="Kraśnik">Kraśnik</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Lublin" name="category" />
                                            <label for="Lublin">Lublin</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Opole Lubelskie" name="category" />
                                            <label for="Opole Lubelskie">Opole Lubelskie</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Radzyń Podlaski" name="category" />
                                            <label for="Radzyń Podlaski">Radzyń Podlaski</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Ryki" name="category" />
                                            <label for="Ryki">Ryki</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Świdnik" name="category" />
                                            <label for="Świdnik">Świdnik</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Włodawa" name="category" />
                                            <label for="Włodawa">Włodawa</label>
                                            </div>

                                            <label class="district" for="">woj. lubuskie</label>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Gorzów Wielkopolski" name="category" />
                                            <label for="Gorzów Wielkopolski">Gorzów Wielkopolski</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Słubice" name="category" />
                                            <label for="Słubice">Słubice</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Zielona Góra" name="category" />
                                            <label for="Zielona Góra">Zielona Góra</label>
                                            </div>

                                            <label class="district" for="">woj. łódzkie</label>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Głowno" name="category" />
                                            <label for="Głowno">Głowno</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Łódź" name="category" />
                                            <label for="Łódź">Łódź</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Pabianice" name="category" />
                                            <label for="Pabianice">Pabianice</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Wieluń" name="category" />
                                            <label for="Wieluń">Wieluń</label>
                                            </div>

                                            <label class="district" for="">woj. małopolskie</label>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Białka Tatrzańska" name="category" />
                                            <label for="Białka Tatrzańska">Białka Tatrzańska</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Brzesko" name="category" />
                                            <label for="Brzesko">Brzesko</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Chrzanów" name="category" />
                                            <label for="Chrzanów">Chrzanów</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Dąbrowa Tarnowska" name="category" />
                                            <label for="Dąbrowa Tarnowska">Dąbrowa Tarnowska</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Jabłonka" name="category" />
                                            <label for="Jabłonka">Jabłonka</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Kęty" name="category" />
                                            <label for="Kęty">Kęty</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Krynica Zdrój" name="category" />
                                            <label for="Krynica Zdrój">Krynica Zdrój</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Limanowa" name="category" />
                                            <label for="Limanowa">Limanowa</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Modlniczka k/Krakowa" name="category" />
                                            <label for="Modlniczka k/Krakowa">Modlniczka k/Krakowa</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Mszana Dolna" name="category" />
                                            <label for="Mszana Dolna">Mszana Dolna</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Muszyna" name="category" />
                                            <label for="Muszyna">Muszyna</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Myślenice" name="category" />
                                            <label for="Myślenice">Myślenice</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Nowy Sącz" name="category" />
                                            <label for="Nowy Sącz">Nowy Sącz</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Nowy Targ" name="category" />
                                            <label for="Nowy Targ">Nowy Targ</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Olkusz" name="category" />
                                            <label for="Olkusz">Olkusz</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Oświęcim" name="category" />
                                            <label for="Oświęcim">Oświęcim</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Sucha Beskidzka" name="category" />
                                            <label for="Sucha Beskidzka">Sucha Beskidzka</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Tarnów" name="category" />
                                            <label for="Tarnów">Tarnów</label>
                                            </div>
                                
                                            <label class="district" for="">woj. mazowieckie</label>

                                            <div class="option">
                                            <input type="radio" class="radio" id="Grodzisk Mazowiecki" name="category" />
                                            <label for="Grodzisk Mazowiecki">Grodzisk Mazowiecki</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Grójec" name="category" />
                                            <label for="Grójec">Grójec</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Mińsk Mazowiecki" name="category" />
                                            <label for="Mińsk Mazowiecki">Mińsk Mazowiecki</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Ostrów Mazowiecka" name="category" />
                                            <label for="Ostrów Mazowiecka">Ostrów Mazowiecka</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Przasnysz" name="category" />
                                            <label for="Przasnysz">Przasnysz</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Siedlce" name="category" />
                                            <label for="Siedlce">Siedlce</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Sokołów Podlaski" name="category" />
                                            <label for="Sokołów Podlaski">Sokołów Podlaski</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Warka" name="category" />
                                            <label for="Warka">Warka</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Warszawa" name="category" />
                                            <label for="Warszawa">Warszawa</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Wyszków" name="category" />
                                            <label for="Wyszków">Wyszków</label>
                                            </div>

                                            <label class="district" for="">woj. opolskie</label>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Jarosław" name="category" />
                                            <label for="Jarosław">Jarosław</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Jasło" name="category" />
                                            <label for="Jasło">Jasło</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Krasne" name="category" />
                                            <label for="Krasne">Krasne</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Krosno" name="category" />
                                            <label for="Krosno">Krosno</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Lesko" name="category" />
                                            <label for="Lesko">Lesko</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Rzeszów" name="category" />
                                            <label for="Rzeszów">Rzeszów</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Stalowa Wola" name="category" />
                                            <label for="Stalowa Wola">Stalowa Wola</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Tarnobrzeg" name="category" />
                                            <label for="Tarnobrzeg">Tarnobrzeg</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Ustrzyki Dolne" name="category" />
                                            <label for="Ustrzyki Dolne">Ustrzyki Dolne</label>
                                            </div>

                                            <label class="district" for="">woj. podlaskie</label>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Białystok" name="category" />
                                            <label for="Białystok">Białystok</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Siemiatycze" name="category" />
                                            <label for="Siemiatycze">Siemiatycze</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Sokółka" name="category" />
                                            <label for="Sokółka">Sokółka</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Zambrów" name="category" />
                                            <label for="Zambrów">Zambrów</label>
                                            </div>

                                            <label class="district" for="">woj. pomorskie</label>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Bytów" name="category" />
                                            <label for="Bytów">Bytów</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Chojnice" name="category" />
                                            <label for="Chojnice">Chojnice</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Kartuzy" name="category" />
                                            <label for="Kartuzy">Kartuzy</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Kwidzyn" name="category" />
                                            <label for="Kwidzyn">Kwidzyn</label>
                                            </div>

                                            <label class="district" for="">woj. śląskie</label>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Bielsko-Biała" name="category" />
                                            <label for="Bielsko-Biała">Bielsko-Biała</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Chorzów" name="category" />
                                            <label for="Chorzów">Chorzów</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Czechowice-Dziedzice" name="category" />
                                            <label for="Czechowice-Dziedzice">Czechowice-Dziedzice</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Częstochowa" name="category" />
                                            <label for="Częstochowa">Częstochowa</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Łaziska Górne" name="category" />
                                            <label for="Łaziska Górne">Łaziska Górne</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Siemianowice Śląskie" name="category" />
                                            <label for="Siemianowice Śląskie">Siemianowice Śląskie</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Tarnowskie Góry" name="category" />
                                            <label for="Tarnowskie Góry">Tarnowskie Góry</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Tychy" name="category" />
                                            <label for="Tychy">Tychy</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Ustroń" name="category" />
                                            <label for="Ustroń">Ustroń</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Wisła" name="category" />
                                            <label for="Wisła">Wisła</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Wodzisław Śląski" name="category" />
                                            <label for="Wodzisław Śląski">Wodzisław Śląski</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Zawiercie" name="category" />
                                            <label for="Zawiercie">Zawiercie</label>
                                            </div>

                                            <label class="district" for="">woj. świętokrzyskie</label>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Busko Zdrój" name="category" />
                                            <label for="Busko Zdrój">Busko Zdrój</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Jędrzejów" name="category" />
                                            <label for="Jędrzejów">Jędrzejów</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Kielce" name="category" />
                                            <label for="Kielce">Kielce</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Pińczów" name="category" />
                                            <label for="Pińczów">Pińczów</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Sandomierz" name="category" />
                                            <label for="Sandomierz">Sandomierz</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Staszów" name="category" />
                                            <label for="Staszów">Staszów</label>
                                            </div>

                                            <label class="district" for="">woj. warmińsko-mazurskie</label>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Augustów" name="category" />
                                            <label for="Augustów">Augustów</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Elbląg" name="category" />
                                            <label for="Elbląg">Elbląg</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Ełk" name="category" />
                                            <label for="Ełk">Ełk</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Giżycko" name="category" />
                                            <label for="Giżycko">Giżycko</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Gołdap" name="category" />
                                            <label for="Gołdap">Gołdap</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Olsztyn" name="category" />
                                            <label for="Olsztyn">Olsztyn</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Pisz" name="category" />
                                            <label for="Pisz">Pisz</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Węgorzewo" name="category" />
                                            <label for="Węgorzewo">Węgorzewo</label>
                                            </div>

                                            <label class="district" for="">woj. wielkopolskie</label>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Chodzież" name="category" />
                                            <label for="Chodzież">Chodzież</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Grodzisk Wielkopolski" name="category" />
                                            <label for="Grodzisk Wielkopolski">Grodzisk Wielkopolski</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Jarocin" name="category" />
                                            <label for="Jarocin">Jarocin</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Kępno" name="category" />
                                            <label for="Kępno">Kępno</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Koło" name="category" />
                                            <label for="Koło">Koło</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Nowy Tomyśl" name="category" />
                                            <label for="Nowy Tomyśl">Nowy Tomyśl</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Ostrów Wielkopolski" name="category" />
                                            <label for="Ostrów Wielkopolski">Ostrów Wielkopolski</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Piła" name="category" />
                                            <label for="Piła">Piła</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Pleszew" name="category" />
                                            <label for="Pleszew">Pleszew</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Szamotuły" name="category" />
                                            <label for="Szamotuły">Szamotuły</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Śrem" name="category" />
                                            <label for="Śrem">Śrem</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Środa Wielkopolska" name="category" />
                                            <label for="Środa Wielkopolska">Środa Wielkopolska</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Trzcianka" name="category" />
                                            <label for="Trzcianka">Trzcianka</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Turek" name="category" />
                                            <label for="Turek">Turek</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Wągrowiec" name="category" />
                                            <label for="Wągrowiec">Wągrowiec</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Wolsztyn" name="category" />
                                            <label for="Wolsztyn">Wolsztyn</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Złotów" name="category" />
                                            <label for="Złotów">Złotów</label>
                                            </div>

                                            <label class="district" for="">woj. zachodniopomorskie</label>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Police" name="category" />
                                            <label for="Police">Police</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Sławno" name="category" />
                                            <label for="Sławno">Sławno</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Świdwin" name="category" />
                                            <label for="Świdwin">Świdwin</label>
                                            </div>
                                
                                            <div class="option">
                                            <input type="radio" class="radio" id="Wałcz" name="category" />
                                            <label for="Wałcz">Wałcz</label>
                                            </div>
                                                                    
                                        </div>
                                
                                        <div class="selected">
                                            Wybierz swoje miasto
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="result-area">     
                                <div class="submit"><input type="submit" value="Zapisz się"></div>
                                </div>

                                <div id="loader"><img src="img/loader.gif" alt="loading..."></div>
                                <div id="message-text">Wypełnij wszystkie pola</div>
                            </div>
                    </div>
                </form>
            <div class="info-after-submit">*Przy zakupie powyżej 200 PLN</div>
            <div class="info-after-submit">Nadawcą wiadomości SMS wysyłanych w ramach
                "Klubu SMS" jest OTCF S.A.</div>
            <div class="unsubscribe">Mamy nadzieję, że lubisz dostawać wiadomości od nas.<br>Jeśli nie chcesz być na
                bieżąco z aktualnymi promocjami, nowościami oraz akcjami rabatowymi,<br>możesz wypisać się <a
                    href="unsubscribe.php">tutaj</a></div>
            </div>
        </div>
        
    </div>
    <!--end of root-->

</body>

</html>
<script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
<script src="js/script-v7.js"></script>