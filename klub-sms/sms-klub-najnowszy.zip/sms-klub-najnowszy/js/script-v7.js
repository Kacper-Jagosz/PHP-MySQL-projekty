var emptyFields = false;
var chars = false;
var success = 0;
var checkbox1, checkbox2, checkbox3;
var number = '';
var submit = $('.submit input');
var loader = $('#loader');
var message = $('#message-text');
var availableChars = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"];

let cityName;



function showMessage(text, success) {
    $(message).html(text);
    $(loader).stop().fadeOut(500);
    $(message).fadeIn();

    if (!success) {
        $(message).delay(2000).fadeOut(1000, function () {
            $(submit).fadeIn(500);
        });
    }
}

//create proper wrapper top margin
// function fixWrapperPosition() {

//     if ($(window).width() < 904) {

//         var windowH = $(window).height();
//         var wrapperH = $('.form-wrapper').height() * 2;
//         var margin = windowH - wrapperH + 1;
//         margin > 200 ?
//             $('.form-wrapper').css('margin-top', margin + 'px') :
//             $('.form-wrapper').css('margin-top', '250px');
//     }
// }

function searchContactsByMobilePhone(number) {
    $.ajax({
        url: 'Model/Rest/Methods/Contacts/GetContactByPhoneNumber.php',
        method: 'post',
        data: {
            mobilePhone: number
        },
        success: function (soapResponse) {
            var val = JSON.parse(soapResponse);
            let status = val.meta.status;

            if (status == 200) {
                let contactId = val.data[0].id ?? null;
                //number exists in db so add it to group
                addContactToGroup(contactId);

                if (val.data[0].isUnsubscribeSms == true) {
                    resubscribeContact(contactId);
                }

            } else {
                addContact(number, cityName);
            }
        },
        error: function (SOAPResponse) {
            alert('error');
        }
    });
}

function searchContactsByMobilePhoneUnsubscribe(number) {
    $.ajax({
        url: 'Model/Rest/Methods/Contacts/GetContactByPhoneNumber.php',
        method: 'post',
        data: {
            mobilePhone: number
        },

        success: function (soapResponse) {
            var jsonResponse = JSON.parse(soapResponse);
            let status = jsonResponse.meta.status;

            if (status == 200) {
                contactId = jsonResponse.data[0].id
                //number exists in db so unsubscibe from club sms
                deleteContact(contactId);
            } else {
                showMessage('Podany numer nie jest w naszej bazie');
            }
        },
        error: function (SOAPResponse) {
            alert('error');
        }
    });
}


function addContact(number, cityName) {
    $.ajax({
        url: 'Model/Rest/Methods/Contacts/AddContact.php',
        method: 'post',
        data: {
            mobilePhone: number,
            city: cityName,
        },

        success: function (soapResponse) {
            var jsonResponse = JSON.parse(soapResponse);
            let status = jsonResponse.meta.status;

            if (status == 200) {
                contactId = jsonResponse.data[0].contactId;
                addContactToGroup(contactId);
            } else {
                if (jsonResponse.AddContactResult.Description == 'Niepoprawny numer telefonu/faxu')
                    jsonResponse.AddContactResult.Description = 'Wprowadzony numer telefonu jest nieprawidłowy';
                showMessage(jsonResponse.AddContactResult.Description);
            }
        },
        error: function (SOAPResponse) {
            showMessage('api error');
        }
    });
}

function addContactToGroup(param) {
    $.ajax({
        url: 'Model/Rest/Methods/Contacts/AddContactToGroup.php',
        method: 'post',
        data: {
            contactId: param
        },

        success: function (soapResponse) {
            var jsonResponse = JSON.parse(soapResponse);
            let status = jsonResponse.meta.status;

            if (status == 200) {
                success = 1;
                showMessage("Numer został dodany. Dziękujemy!", success);
            } else {
                if (jsonResponse.AddContactsToGroupResult.Description == 'Ta grupa kontaktów zawiera już podany kontakt')
                    jsonResponse.AddContactsToGroupResult.Description = 'Twój numer telefonu znajduje się już w naszej bazie';

                showMessage(jsonResponse.AddContactsToGroupResult.Description);
            }
        },
        error: function (SOAPResponse) {
            showMessage('api error');
        }
    });
}

function deleteContact(param) {
    $.ajax({
        url: 'Model/Rest/Methods/Contacts/UnsubscribeContact.php',
        method: 'post',
        data: {
            contactIds: param
        },

        success: function (soapResponse) {
            var jsonResponse = JSON.parse(soapResponse);
            let status = jsonResponse.meta.status;

            if (status == 200) {
                showMessage('Twój numer telefonu został usunięty');
            } else {
                showMessage('Niepoprawny numer telefonu');
            }
        },
        error: function (SOAPResponse) {
            showMessage('api error');
        }
    });
}

function resubscribeContact(param) {
    $.ajax({
        url: 'Model/Rest/Methods/Contacts/ResubscribeContact.php',
        method: 'post',
        data: {
            contactIds: param
        },

        success: function (soapResponse) {
            var jsonResponse = JSON.parse(soapResponse);
            let status = jsonResponse.meta.status;

            if (status == 200) {
                showMessage('Twój numer telefonu został ponownie zasubskrybowany');
            } else {
                showMessage(jsonResponse.errors[0].title);
            }
        },
        error: function (SOAPResponse) {
            showMessage('api error');
        }
    });
}

$(document).ready(function () {

    //clear field on focus
    $('.digit input').on('focus', function () {
        $(this).val('');
    });
    var lastInput = 0;
    $('.digit input').keyup(function (e) {
        if (e.keyCode == 8) {
            if ($(this).parent().index() === 9 && lastInput == 0) {
                lastInput = 1;
                $(this).parent().find('input').val('');
            } else {
                lastInput = 0;
                $(this).parent().prev().find('input').val('');
                $(this).parent().prev().find('input').focus();
            }
        }
    });

    //switch to next element after input
    $('.number-wrapper input').on('input', function () {
        if ($(this).parent().next().find('input').val() == '')
            $(this).parent().next().find('input').focus();
    });

    //validate form data
    $('#number-form').submit(function () {
        emptyFields = false;
        chars = false;

        if (success == 0) {
            //tutaj zmiana, bylo 0 w number
            number = '';
            $('.digit').each(function () {

                var digit = $(this).find('input').val();
                number += digit;

                if ($.inArray(digit, availableChars) == -1)
                    chars = true;

                if (!digit)
                    emptyFields = true;
            });

            cityName = $('input[name="category"]:checked').attr('id');
            if (!cityName) {

                emptyFields = true;
            }


            $(submit).fadeOut(500);
            $(loader).fadeIn(500);
            checkbox2 = $('#agree2').is(':checked');
            //checkbox3 = $('#agree3').is(':checked');

            if (emptyFields) {
                showMessage('Wypełnij wszystkie pola')
            } else if (chars) {
                showMessage('Wprowadź swój numer telefonu')
                //} else if (!checkbox2 || !checkbox3) {
            } else if (!checkbox2) {
                showMessage('Wymagane jest zaznaczenie powyższej zgody')
            } else {
                //check if number exists in database
                searchContactsByMobilePhone(number);
            }
        }
        return false;
    });

    //validate form data - unsubscribe
    $('#number-form-unsubscribe').submit(function () {
        emptyFields = false;
        chars = false;

        if (success == 0) {
            //tutaj number byl z 0 na przodzie
            number = '';
            $('.digit').each(function () {

                var digit = $(this).find('input').val();
                number += digit;

                if ($.inArray(digit, availableChars) == -1)
                    chars = true;

                if (!digit)
                    emptyFields = true;
            });


            $(submit).fadeOut(500);
            $(loader).fadeIn(500);
            // checkbox2 = $('#agree2').is(':checked');
            //checkbox3 = $('#agree3').is(':checked');

            if (emptyFields) {
                showMessage('Wypełnik wszystkie pola')
            } else if (chars) {
                showMessage('Wprowadź swój numer telefonu')
            } else {
                //check if number exists in database
                searchContactsByMobilePhoneUnsubscribe(number);
            }
        }
        return false;
    });

    // $(window).resize(fixWrapperPosition);
    // fixWrapperPosition();
});


// city selection

const selected = document.querySelector(".desktop-select-container .selected");
const optionsContainer = document.querySelector(".desktop-select-container .options-container");

const optionsList = document.querySelectorAll(".desktop-select-container .option");

selected.addEventListener("click", () => {
    optionsContainer.classList.toggle("active");
});

document.body.addEventListener('click', function (e) {
    if (!e.target.classList.contains('selected')) {
        optionsContainer.classList.remove("active");
    }
});


// mainBg.addEventListener("click", () => {
//   optionsContainer.classList.remove("active");
// });

optionsList.forEach(option => {
    option.addEventListener("click", () => {
        selected.innerHTML = option.querySelector("label").innerHTML;
        optionsContainer.classList.remove("active");
    });
});




