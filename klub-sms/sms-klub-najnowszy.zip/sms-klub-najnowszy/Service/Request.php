<?php

namespace Otcf\ClubSMS\Service;

use Otcf\ClubSMS\Config;
use Otcf\ClubSMS\HTTP\Client;
use Otcf\ClubSMS\Logger;

require $_SERVER['DOCUMENT_ROOT'] . "/sms-klub/HTTP/Client/Curl.php";
require $_SERVER['DOCUMENT_ROOT'] . "/sms-klub/Config/Config.php";
require $_SERVER['DOCUMENT_ROOT'] . "/sms-klub/Logger/Logger.php";

class Request
{
    /**
     * @var Curl
     */
    private $curlClient;

    /**
     * @var Config
     */
    private $config;

    /**
     * @var Logger
     */
    private $logger;

    public function __construct(
    ) {
        $this->curlClient = new Client\Curl();
        $this->config = Config\Config::getInstance();
        $this->logger = new Logger\Logger();
    }

    public function getConfigurationFromSingleton()
    {
        return $this->config->getConfiguration();
    }

    private function getCurlClient()
    {
        return $this->curlClient;
    }

    private function getOrPostData($url, $postData = null, $request = 'get', $customRequest = null)
    {
        try {
            $this->getCurlClient()->setHeaders(
                $this->getConfigurationFromSingleton()["ApiHeaders"]
            );
            
            $request == 'get' ?
            $this->getCurlClient()->get($url) :
            $this->getCurlClient()->post($url, $postData, $customRequest);

        } catch (\Exception $e) {
            $this->logger->warning($e, __FILE__);
        }
    }

    private function postBodyData($url, $postData, $customRequest = null)
    {
        $this->getJsonData($url, [], $postData, 'post', $customRequest);
        return $this->getCurlClient()->getBody();
    }

    private function getBodyData($url, $query = [])
    {
        $this->getJsonData($url, $query);
        return $this->getCurlClient()->getBody();
    }

    private function generateQuery(array $array)
    {
        $queryArray = [];

        if (empty($array)) {
            return '';
        }

        foreach ($array as $key => $value) {
            array_push($queryArray, $key . '=' . $value);
        }

        return implode('&', $queryArray);
    }

    private function getJsonData(string $url, array $query = [], $postData = [], $request = 'get', $customRequest = null)
    {
        if ($request == 'get') {
            $queryString = null;

            if (!empty($query)) {
                $queryString = $this->generateQuery($query);
            }

            $apiUrl = $url;

            if (!is_null($queryString)) {
                $apiUrl = $apiUrl . '?' . $queryString;
            }

            $this->getOrPostData($apiUrl);

            return json_decode($this->getCurlClient()->getBody(), true);
        } else {
            $apiUrl = $url;
            $this->getOrPostData($apiUrl, $postData, 'post', $customRequest);

            return [
                "status" => $this->getCurlClient()->getStatus(),
                "body" => json_decode($this->getCurlClient()->getBody(), true),
            ];
        }
    }

    public function addContact($postData)
    {
        try {
            return $this->postBodyData($this->getConfigurationFromSingleton()["AddContact"]["Url"], $postData);
        } catch (\Exception $e) {
            $this->logger->warning($e, __FILE__);
        }
    }

    public function addContactToGroup($postData)
    {
        try {
            return $this->postBodyData($this->getConfigurationFromSingleton()["AddContactToGroup"]["Url"], $postData);
        } catch (\Exception $e) {
            $this->logger->warning($e, __FILE__);
        }
    }

    public function createGroup($postData)
    {
        try {
            return $this->postBodyData($this->getConfigurationFromSingleton()["CreateGroup"]["Url"], $postData);
        } catch (\Exception $e) {
            $this->logger->warning($e, __FILE__);
        }
    }

    public function deleteContacts($postData)
    {
        try {
            return $this->postBodyData($this->getConfigurationFromSingleton()["DeleteContact"]["Url"], $postData, 'DELETE');
        } catch (\Exception $e) {
            $this->logger->warning($e, __FILE__);
        }
    }

    public function unsubscribeContacts($postData)
    {
        try {
            return $this->postBodyData($this->getConfigurationFromSingleton()["UnsubscribeContact"]["Url"], $postData);
        } catch (\Exception $e) {
            $this->logger->warning($e, __FILE__);
        }
    }

    public function resubscribeContacts($postData)
    {
        try {
            return $this->postBodyData($this->getConfigurationFromSingleton()["ResubscribeContact"]["Url"], $postData);
        } catch (\Exception $e) {
            $this->logger->warning($e, __FILE__);
        }
    }

    public function getAllContacts()
    {
        try {
            $query =
                [
                "limit" => $this->getConfigurationFromSingleton()["GetAllContacts"]["Limit"],
            ];

            return $this->getBodyData($this->getConfigurationFromSingleton()["GetAllContacts"]["Url"], $query);
        } catch (\Exception $e) {
            $this->logger->warning($e, __FILE__);
        }
    }

    public function getAllGroups()
    {
        try {
            $query =
                [
                "limit" => $this->getConfigurationFromSingleton()["GetAllGroups"]["Limit"],
            ];

            return $this->getBodyData($this->getConfigurationFromSingleton()["GetAllGroups"]["Url"], $query);
        } catch (\Exception $e) {
            $this->logger->warning($e, __FILE__);
        }
    }

    public function getContactByPhoneNumber($phoneNumber)
    {
        try {
            $query =
                [
                "phoneNumber" => $phoneNumber,
            ];

            return $this->getBodyData($this->getConfigurationFromSingleton()["GetAllContacts"]["Url"], $query);
        } catch (\Exception $e) {
            $this->logger->warning($e, __FILE__);
        }
    }
}

