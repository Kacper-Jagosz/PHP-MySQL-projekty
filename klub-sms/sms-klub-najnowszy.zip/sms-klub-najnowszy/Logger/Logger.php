<?php

namespace Otcf\ClubSMS\Logger;

class Logger
{
    const FILENAME = 'exceptions.log';
    public $filePath;

    public function __construct()
    {
        $this->filePath = $_SERVER['DOCUMENT_ROOT'] . '/log/exceptions.log';
    }

    public function warning($message, $file)
    {
        if (!file_exists($this->filePath)) {
            mkdir($this->filePath, 0777, true);
        } else {
            file_put_contents($this->filePath, $this->getMessage($message, $file), FILE_APPEND);
        }

    }

    private function getMessage($message, $file): string
    {
        $currentData = date("Y/m/d H:i:s");
        $exceptionMessage = 'WARNING FROM:' . $file . ' ' . $currentData . "\n Message: " . $message . PHP_EOL;

        return $exceptionMessage;
    }
}
