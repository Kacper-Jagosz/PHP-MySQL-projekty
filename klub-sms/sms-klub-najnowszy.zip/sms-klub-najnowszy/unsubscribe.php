<!DOCTYPE html>
<html lang="pl">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<!--<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" /> -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700|Roboto+Condensed:700&amp;subset=latin-ext" rel="stylesheet">
	<link rel="stylesheet" href="css/style-v8.css" media="screen">
  <title>Outhorn Klub SMS</title>
	<link rel="shortcut icon" href="https://outhorn.com/gfx/i1567171356.ico">
	<link rel="icon" href="https://outhorn.com/gfx/i1567171356.ico">
</head>
<body>
	<div id="bg"></div>
	<div id="root">

	<a href="https://outhorn.com/">
			<div id="logo"><img src="img/logo-oth-v5.png" alt=""></div>
            <div id="newsletter-logo"><img src="img/header-v5.png" alt=""></div>
        </a>


		<div class="form-wrapper">

		<p class="news-descript">Jeśli nie chcesz być na bieżąco z aktualnymi promocjami, nowościami oraz akcjami rabatowymi, możesz wypisać się tutaj:</p>
		<br><br><br>

			<h2>Wypisz się z Klubu SMS</h2>

			<!-- <ul class="list-a">
				<li>aktualnych promocjach</li>
				<li>nowościach w ofercie</li>
				<li>specjalnych akcjach rabatowych</li>
			</ul> -->

			<div class="number-wrapper">

				<form method="post" action="" id="number-form-unsubscribe">
					<div class="digits">
						<span class="number">+48</span>
						<div class="digit"><input name="digit-1" type="text" maxlength="1" placeholder="_" required /></div>
						<div class="digit"><input name="digit-2" type="text" maxlength="1" placeholder="_" required /></div>
						<div class="digit"><input name="digit-3" type="text" maxlength="1" placeholder="_" required /></div>
						<div class="digit"><input name="digit-4" type="text" maxlength="1" placeholder="_" required /></div>
						<div class="digit"><input name="digit-5" type="text" maxlength="1" placeholder="_" required /></div>
						<div class="digit"><input name="digit-6" type="text" maxlength="1" placeholder="_" required /></div>
						<div class="digit"><input name="digit-7" type="text" maxlength="1" placeholder="_" required /></div>
						<div class="digit"><input name="digit-8" type="text" maxlength="1" placeholder="_" required /></div>
						<div class="digit"><input name="digit-9" type="text" maxlength="1" placeholder="_" required /></div>
					</div>
					<!-- <div class="checkbox">
						<input type="checkbox" id="agree1" value="true"  /><label for="agree1"><span></span>Wyrażam zgodę na przetwarzanie moich danych osobowych i wykorzystywanie ich w celach marketingowych (zgodnie z ustawą z dnia 29.08.1997r. o ochronie danych osobowych, tj. Dz.U z 2002 roku, nr 101, poz. 926 z późn. zm.) przez OTCF Sp. z o.o. z siedzibą w Wieliczce (32-020) ul. Grottgera 30, wpisaną do KRS pod nr 0000555276 prowadzonego przez Wydział Gospodarczy Sadu Rejonowego w Krakowie.</label>
					</div> -->
					<!-- <div class="checkbox">
						<input type="checkbox" id="agree2" value="true"  /><label for="agree2"><span></span>Wyrażam zgodę na otrzymywanie korespondencji handlowej w postaci wiadomości SMS zgodnie z <a href="https://4f.com.pl/regulamin,8,51.htm">Regulaminem Sklepu Internetowego</a>. Przysługuje mi prawo cofnięcia zgody na przetwarzania danych w każdym czasie, co nie będzie jednak miało wpływu na zgodność przetwarzania z prawem realizowanego przed cofnięciem zgody.</a></label>
					</div> -->
					<div class="checkbox">
						<!-- <input type="checkbox" id="agree3" value="true"  /><label for="agree3"><span></span>Wyrażam zgodę na przetwarzanie mojego numeru telefonu przez OTCF S.A. w celu otrzymywania wiadomości „Newsletter SMS”.</label> -->
					</div>

					<div class="result-area">
						<div class="submit"><input type="submit" value="Zrezygnuj" /></div>
						<div id="loader"><img src="img/loader.gif" alt='loading...' /></div>
						<div id="message-text">Wypełnij wszystkie pola</div>
					</div>

				</form>
			</div>
			<!-- <div class="info-after-submit">Nadawcą wiadomości SMS wysyłanych w ramach "Klubu SMS" jest OTCF S.A.</div> -->
		</div>

	</div><!--end of root-->

</body>
</html>
<script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
<script src="js/script-v7.js"></script>
