<?php

namespace Otcf\ProductFeeds\Model\Executor;

use Otcf\ProductFeeds\Config\Config;
use Otcf\ProductFeeds\Service\Request;
use \Magento\Framework\Xml\Parser;
use Otcf\ProductFeeds\Model\Csv\CreateCsv;
use Otcf\ProductFeeds\Model\Csv\CsvDiff;

class Executor
{
    /**
     * @var Config
     */
    private $config;

    /**
     * @var Request
     */
    private $request;

    /**
     * @var Parser
     */
    private $parser;

    /**
     * @var CreateCsv
     */
    private $createCsv;

    /**
     * @var CsvDiff
     */
    private $csvDiff;

    public function __construct(
        Request $request,
        Parser $parser,
        CreateCsv $createCsv,
        CsvDiff $csvDiff
    ) {
        $this->config = Config::getInstance();
        $this->request = $request;
        $this->parser = $parser;
        $this->createCsv = $createCsv;
        $this->csvDiff = $csvDiff;
    }

    public function execute()
    {
        $config = $this->config->getConfiguration()["feeds"];

        foreach ($config as $feedConfig) {
            foreach ($feedConfig as $key => $feedData) {
                $feedUrl = $feedData['url'];
                $filename = $feedData['name'];

                $this->request->getXmlFile($feedUrl, $filename);
                $parsedData = $this->parser->load($feedUrl)->xmlToArray();
                $this->createCsv->createReducedCsv($filename, $parsedData);
                $this->csvDiff->csvDiffSaveToFile($filename);
            }
        }
    }
}
