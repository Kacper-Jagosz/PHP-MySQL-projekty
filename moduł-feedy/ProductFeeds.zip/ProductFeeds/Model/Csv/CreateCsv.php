<?php

namespace Otcf\ProductFeeds\Model\Csv;

use Exception;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem;
use Otcf\ProductFeeds\Model\Csv\CsvReader;

class CreateCsv
{
    /**
     * @var Filesystem
     */
    private $filesystem;

    private $directory;

    private $csvReader;

    public function __construct(
        Filesystem $filesystem,
        CsvReader $csvReader
    ) {
        $this->directory = $filesystem->getDirectoryWrite(DirectoryList::MEDIA);
        $this->csvReader = $csvReader;
    }

    public function createReducedCsv(string $filename, array $parsedCollection)
    {
        $filePath =  "4f_feeds/feeds/" . date("d-m-y") . '/r_' . $filename . '.csv';
        $this->directory->create('export');
        $stream = $this->directory->openFile($filePath, 'w+');
        $stream->lock();
        $header = ['id'];
        $stream->writeCsv($header);

        foreach ($this->getParsedDataProductCollection($parsedCollection, $filename) as $productData) {
            $data = [];
            $data[] = $productData['g:id'];
            $stream->writeCsv($data);
        }

        // print("<pre>".print_r($parsedCollection,true)."</pre>");
        // foreach ($parsedCollection['feed']['entry'] as $productData) {
        //     $data = [];
        //     $data[] = $productData['g:id'];
        //     $stream->writeCsv($data);
        // }

        $this->csvReader->readCsv();
    }

    public function createDiffCsv(string $filename, array $dataDifferences)
    {
        $filePath =  "4f_feeds/feeds/" . date("d-m-y") . '/diff_' . $filename . '.csv';
        $this->directory->create('export');
        $stream = $this->directory->openFile($filePath, 'w+');
        $stream->lock();
        $header = ['curr_to_prev', 'prev_to_current'];
        $stream->writeCsv($header, ';');

        $data = [];
        foreach ($dataDifferences as $key => $differencesArray) {
            foreach ($differencesArray as $rowData) {
                if ($key == 'curr_to_prev') {
                    $data['curr_to_prev'][] = $rowData;
                } else {
                    $data['prev_to_curr'][] = $rowData;
                }
            }
        }

        foreach ($data as $name => $idsArray) {
            foreach ($idsArray as $key => $productId) {
                $csvRowData = [];
                $csvRowData[] = $productId;
                $csvRowData[] = $data['prev_to_curr'][$key] ?? '';
                $stream->writeCsv($csvRowData, ';');
            }
            return true;
        }
    }

    public function getParsedDataProductCollection(array $parsedCollection, string $filename): array
    {
        try{

        
        if(str_contains($filename, 'fb')) {
            return $parsedCollection['feed']['entry'];
        }
        return $parsedCollection['rss']['_value']['channel']['item'];
    } catch(\Exception $e) {
        var_dump($filename);
        print("<pre>".print_r($parsedCollection,true)."</pre>");  die;

    }
    }
}
