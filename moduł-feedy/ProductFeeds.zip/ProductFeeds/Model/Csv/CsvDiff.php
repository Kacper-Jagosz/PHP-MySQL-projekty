<?php

namespace Otcf\ProductFeeds\Model\Csv;

use Otcf\ProductFeeds\Model\Csv\CsvReader;
use Otcf\ProductFeeds\Model\Csv\CreateCsv;
use Otcf\ProductFeeds\Model\File\File;

class CsvDiff
{
    /**
     * @var CsvReader
     */
    private $csvReader;
    
    /**
     * @var CreateCsv
     */
    private $createCsv;
    
    /**
     * @var File
     */
    private $file;
  
    public function __construct(
        CsvReader $csvReader,
        CreateCsv $createCsv,
        File $file
    ) {
        $this->csvReader = $csvReader;
        $this->createCsv = $createCsv;
        $this->file = $file;
    }

    public function csvDiffSaveToFile(string $filename)
    {
        $currentDate = date("d-m-y");
        $previousDate = date("d-m-y", strtotime('-1 days'));

        if ($this->file->isFileExists($previousDate, $filename)) {
            $currentData = $this->csvReader->readCsv($currentDate . '/r_' . $filename . '.csv');
            $reducedCurrentData = $this->changeDimension($currentData);

            $previousData = $this->csvReader->readCsv($previousDate . '/r_' . $filename . '.csv');
            $reducedPreviousData = $this->changeDimension($previousData);

            $dataDifferences = [
                "curr_to_prev" => array_diff($reducedCurrentData, $reducedPreviousData),
                "prev_to_curr" => array_diff($reducedPreviousData, $reducedCurrentData)
            ];
            // print("<pre>".print_r($dataDifferences,true)."</pre>");

            // $currentToPrevious = array_diff_assoc($reducedCurrentData, $reducedPreviousData);
            // $previousToCurrent = array_diff_assoc($reducedPreviousData, $reducedCurrentData);

            $this->createCsv->createDiffCsv($filename, $dataDifferences);
        }
    }

    public function changeDimension(array $data): ?array
    {
        $reducedData = [];

        foreach ($data as $rowData) {
            $reducedData[] = $rowData[0];
        }

        return $reducedData;
    }


}
