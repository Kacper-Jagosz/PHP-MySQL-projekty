<?php

namespace Otcf\ProductFeeds\Model\Csv;

use Exception;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem\Driver\File;
use Magento\Framework\File\Csv;

class CsvReader
{
    /**
     * @var DirectoryList
     */
    protected $directoryList;
    /**
     * @var Csv
     */
    protected $csv;
    /**
     * @var File
     */
    protected $file;

    /**
     * @var StatusLogger
     */
    private $statusLogger;

    /**
     * @var ExceptionLogger
     */    
    private $exceptionLogger;

    public function __construct(
        DirectoryList $directoryList,
        Csv $csv,
        File $file,
    ) {
        $this->directoryList = $directoryList;
        $this->csv = $csv;
        $this->file = $file;
    }

    /**
     * Reads a specified csv file
     *
     * This method return array of excel data.
     *
     * @param string $filename CSV file name
     */
    // public function readCsv($filePath = 'test/Zeszyt2uk.csv')
    public function readCsv($filePath = '22-02-23/r_pl_product_feed.csv')
    {
        $csvFilePath = '/pub/media/4f_feeds/feeds/' . $filePath;
        $rootDirectory = $this->directoryList->getRoot();
        $csvFile = $rootDirectory . "/" . $csvFilePath;
        try {
            if ($this->file->isExists($csvFile)) {
                $csvData = $this->csv->getData($csvFile);
                return $csvData;

                // $csvFileUS = $csvFile = $rootDirectory . "/" . '/pub/media/4f_feeds/feeds/' . 'test/Zeszyt2us.csv';
                // $csvDataUs = $this->csv->getData($csvFileUS);
                

                // $usData = [];
                // $ukData = [];
                // // // var_dump($csvData[0]);

                // foreach($csvData as $rowData) {
                //     $ukData[] = $rowData[0];
                // }

                
                // foreach($csvDataUs as $rowData) {
                //     $usData[] = $rowData[0];
                // }
                // // print("<pre>".print_r($usData,true)."</pre>");
                // // print("<pre>".print_r($ukData,true)."</pre>"); die
                
                // var_dump('diff us to uk');
                // print("<pre>".print_r(array_diff($usData, $ukData),true)."</pre>");
                // var_dump('array diff uk to us');
                // print("<pre>".print_r(array_diff($ukData, $usData),true)."</pre>");

                // die;
            }
        } catch (Exception $e) {
            var_dump($e);
            // $this->statusLogger->warning('Something went wrong, check: img_service_exception.log ');
            // $this->exceptionLogger->warning($e);
        }
    }
}
