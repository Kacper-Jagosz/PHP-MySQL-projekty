<?php

namespace Otcf\ProductFeeds\Model\Directory;

use Exception;
use Magento\Framework\Filesystem;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Filesystem\Directory\WriteInterface;
use \Magento\Framework\Filesystem\Io\File;
use Magento\Framework\Filesystem\Driver\File as DriverFile;
// use Otcf\ProductFeeds\Logger\StatusLogger;
// use Otcf\ProductFeeds\Logger\ExceptionLogger;

class Directory
{
    /**
     * @var Filesystem
     */
    protected $file;

    /**
     * @var WriteInterface
     */
    protected $newDirectory;

    /**
     * @var File
     */
    protected $filesystemIo;

    /**
     * @var DriverFile
     */
    protected $driverFile;

    /**
     * @var StatusLogger
     */
    private $statusLogger;

    /**
     * @var ExceptionLogger
     */
    private $exceptionLogger;

    public function __construct(
        Filesystem $file,
        File $filesystemIo,
        DriverFile $driverFile,
        // StatusLogger $statusLogger,
        // ExceptionLogger $exceptionLogger,
    ) {
        $this->newDirectory = $file->getDirectoryWrite(DirectoryList::MEDIA);
        $this->filesystemIo = $filesystemIo;
        $this->driverFile = $driverFile;
        // $this->statusLogger = $statusLogger;
        // $this->exceptionLogger = $exceptionLogger;
    }

    /**
     * Creates new folder
     *
     * @return bool
     * @throws LocalizedException
     */
    public function createDirectory()
    {
        $logPath = "/4f_feeds/feeds/" . date("d-m-y");
        $newDirectory = false;

        try {
            $newDirectory = $this->newDirectory->create($logPath);
        } catch (FileSystemException  $e) {
            $this->statusLogger->warning('Something went wrong, check: img_service_exception.log');
            $this->exceptionLogger->warning($e->getMessage(), [], $this);
            throw new LocalizedException(
                __('We can\'t create directory "%1"', $logPath)
            );
        }
        return $newDirectory;
    }

    /**
     * Moves file to new directory, and remove from previous
     *
     * @param string $filePath - The file path
     */
    public function moveAndDeleteFile(string $filePath)
    {
        $filename =  explode("/", $filePath);
        $targetDirectoryName = "/4f_feeds/feeds/" . date('d-m-y') . '/' . $filename[2];

        $absoluteFilePath = $this->newDirectory->getAbsolutePath() . $filePath; 
        $absoluteTargetDirectoryName = $this->newDirectory->getAbsolutePath() . $targetDirectoryName; 

        $this->filesystemIo->cp($absoluteFilePath, $absoluteTargetDirectoryName);
        $this->driverFile->deleteFile($absoluteFilePath);
    }


}
