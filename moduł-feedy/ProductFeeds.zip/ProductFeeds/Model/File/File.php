<?php

namespace Otcf\ProductFeeds\Model\File;

use Magento\Framework\Filesystem;
use Magento\Framework\App\Filesystem\DirectoryList;
use Otcf\ProductFeeds\Model\Directory\Directory;
use Magento\Framework\Filesystem\Driver\File as FileDriver;

class File
{

    /**
     * @var Filesystem
     */
    private $filesystem;

    /**
     * @var DirectoryList
     */
    private $directoryList;

    /**
     * @var Directory
     */
    private $directory;

    /**
     * @var FileDriver
     */
    private $fileDriver;

    protected $mediaDirectoryPath;

    public function __construct(
        Filesystem $filesystem,
        // DirectoryList $directoryLis,
        Directory $directory,
        FileDriver $fileDriver
    ) {
        $this->filesystem = $filesystem;
        // $this->directoryList = $directoryList;
        $this->directory = $directory;
        $this->fileDriver = $fileDriver;
    }

    public function saveFile ($file, $filename)
    {
        $this->directory->createDirectory();
        $path =  "4f_feeds/feeds/" . date("d-m-y") . '/' . $filename . '.xml'; 

        $mediaDirectoryPath = $this->filesystem->getDirectoryWrite(DirectoryList::MEDIA);
        $mediaDirectoryPath->writeFile($path, $file);
    }

    public function isFileExists (string $previousDate, string $filename) :bool
    {
        $filePath = $previousDate . '/r_' . $filename . '.csv';
        $rootDir = '/var/www/html/magento/pub/media/4f_feeds/feeds/';

        return $this->fileDriver->isExists($rootDir . $filePath) ?? false; 
    }
}