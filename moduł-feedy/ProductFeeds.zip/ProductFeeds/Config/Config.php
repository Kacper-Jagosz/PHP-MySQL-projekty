<?php

namespace Otcf\ProductFeeds\Config;

use Otcf\ProductFeeds\Api\Singleton\SingletonInterface;

class Config implements SingletonInterface
{
    /**
     * @var Config
     */
    private static $_instance = null;

    /**
     * @var Array
     */
    private array $configuration;

    private function __construct()
    {
        $file = file_get_contents("/var/www/html/magento/app/code/Otcf/ProductFeeds/Config/configuration.json");
        $this->configuration = json_decode($file, true);
    }

    /**
     * {@inheritdoc}
     */
    public static function getInstance(): Config
    {
        if (self::$_instance == null) {
            self::$_instance = new Self;
        }
        return self::$_instance;
    }

    public function __destruct()
    {
        self::$_instance = null;
    }

    /**
     * This method returns configuration from config file.
     */
    public function getConfiguration() 
    {
        return $this->configuration;
    }
}
