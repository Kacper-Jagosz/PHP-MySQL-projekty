<?php

namespace Otcf\ProductFeeds\Api\Singleton;

interface SingletonInterface
{
    /**
     * This method returns current instance.
     */
    public static function getInstance();
}