<?php

namespace Otcf\ProductFeeds\Cron;

use Psr\Log\LoggerInterface;
use Otcf\ProductFeeds\Model\Executor\Executor;

class ServiceExecutor
{
    protected $logger;

    /**
     * @var Executor
     */
    private $executor;

    public function __construct(
        LoggerInterface $logger,
        Executor $executor
    ) {
        $this->logger = $logger;
        $this->executor = $executor;
    }
    /**
     * Write to system.log
     *
     * @return void
     */
    public function execute()
    {
        $this->executor->execute();
        // $this->logger->info('Cron Works');
    }
}
