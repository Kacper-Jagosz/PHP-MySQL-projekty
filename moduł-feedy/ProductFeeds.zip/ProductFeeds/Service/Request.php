<?php

namespace Otcf\ProductFeeds\Service;

use Otcf\ProductFeeds\Config\Config;
use \Magento\Framework\HTTP\Client\Curl;
use Otcf\Logger\Logger\Logger;
use Helpers\Helpers;
use Otcf\ProductFeeds\Model\File\File;
// use Magento\Framework\Filesystem;
// use Magento\Framework\App\Filesystem\DirectoryList;
use \Magento\Framework\Xml\Parser;

class Request
{
    /**
     * @var Curl
     */
    private $curlClient;

    /**
     * @var Config
     */
    private $config;

    /**
     * @var Logger
     */
    private $logger;

    private $fileSystem;

    private $parser;

    private $file;

    public function __construct(
        Curl $curlClient,
        Logger $logger,
        // Filesystem $fileSystem,
        Parser $parser,
        File $file
    ) {
        $this->curlClient = $curlClient;
        $this->logger = $logger;
        $this->config = Config::getInstance();
        // $this->fileSystem = $fileSystem;
        $this->parser = $parser;
        $this->file = $file;
    }

    /**
     * This method returns Configuraton from Singleton instance.
     */
    public function getConfigurationFromSingleton()
    {
        return $this->config->getConfiguration();
    }

    private function getCurlClient()
    {
        return $this->curlClient;
    }

    private function getBody()
    {
        return $this->getCurlClient()->getBody();
    }

    private function getOrPostData($url, $postData = null, $request = 'get', $customRequest = null)
    {
        try {
            // $this->getCurlClient()->setHeaders(
            //     $this->getConfigurationFromSingleton()["ApiHeaders"]
            // );

            if (!is_null($customRequest)) {
                $this->getCurlClient()->setOption(CURLOPT_CUSTOMREQUEST, $customRequest);
            }

            $request == 'get' ?
                $this->getCurlClient()->get($url) :
                $this->getCurlClient()->post($url, $postData);
        } catch (\Exception $e) {
            $this->logger->addWarning($e->getMessage());
        }
    }

    private function postBodyData($url, $postData, $customRequest = null)
    {
        $this->getJsonData($url, [], $postData, 'post', $customRequest);
        return $this->getCurlClient()->getBody();
    }

    private function getBodyData($url, $query = [])
    {
        $this->getJsonData($url, $query);
        // return $this->getCurlClient()->getBody();
        return $this->getBody();
    }

    private function generateQuery(array $array)
    {
        $queryArray = [];

        if (empty($array)) {
            return '';
        }

        foreach ($array as $key => $value) {
            array_push($queryArray, $key . '=' . $value);
        }

        return implode('&', $queryArray);
    }

    private function getJsonData(string $url, array $query = [], $postData = [], $request = 'get', $customRequest = null)
    {
        if ($request == 'get') {
            $queryString = null;

            if (!empty($query)) {
                $queryString = $this->generateQuery($query);
            }

            $apiUrl = $url;

            if (!is_null($queryString)) {
                $apiUrl = $apiUrl . '?' . $queryString;
            }

            $this->getOrPostData($apiUrl);

            return json_decode($this->getBody(), true);
        } else {
            $apiUrl = $url;
            $query = $postData;
            $this->getOrPostData($apiUrl, $query, 'post', $customRequest);

            return [
                "status" => $this->getCurlClient()->getStatus()
                // "body" => json_decode($this->getBody(), true),
            ];
        }
    }

    /**
     * This method calls to Jenkins executor to execute the Service.
     */
    public function callToJenkinsJob($filename)
    {
        try {
            $query = [
                "file" => $filename
            ];

            return $this->postBodyData($this->getConfigurationFromSingleton()["RowDataURL"], $query);
        } catch (\Exception $e) {
            $this->logger->addWarning($e->getMessage());
        }
    }

    public function getXmlFile(string $url, $filename)
    {
        try {
            $file = $this->getBodyData($url);
            $this->file->saveFile($file, $filename);

        } catch (\Exception $e) {
            var_dump($e); die;
            // $this->logger->addWarning($e->getMessage());
        }
    }
}
